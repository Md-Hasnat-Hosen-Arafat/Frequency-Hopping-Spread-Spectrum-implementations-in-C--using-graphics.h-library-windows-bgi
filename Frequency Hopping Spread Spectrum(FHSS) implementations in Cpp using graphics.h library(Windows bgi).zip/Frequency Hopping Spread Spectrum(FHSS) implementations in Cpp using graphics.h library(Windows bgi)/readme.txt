Frequency-hopping spread spectrum (FHSS) is a method of transmitting radio signals by rapidly changing the carrier frequency among many distinct frequencies occupying a large spectral band. The changes are controlled by a code known to both transmitter and receiver.
Input will be 8 patterns of 3-bit i.e.
4 2 1
0 0 0-----0
0 0 1-----1
0 1 0-----2
0 1 1-----3
1 0 0-----4
1 0 1-----5
1 1 0-----6
1 1 1-----7
To get more help:

Youtube link:
part 1: https://youtu.be/Xd7hRNy6AsE
part 2: https://youtu.be/2Dwc8Z9eCqQ

