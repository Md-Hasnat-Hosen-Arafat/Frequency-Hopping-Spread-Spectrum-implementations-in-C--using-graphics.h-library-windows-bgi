#include<iostream>
#include<stdio.h>
#include<conio.h>
#include<graphics.h>
using namespace std;

class FHSS{
    int i,j,k,l,m,n,o,p;
public:
    void fhss_getdata();
    void fhss_graph();
    void fhss_showdata();
};

void FHSS :: fhss_getdata(){

    cout<<"--------------------Enter 8 patterns of 3-bits--------------------"<<endl;
    cin>>i;
    cin>>j;
    cin>>k;
    cin>>l;
    cin>>m;
    cin>>n;
    cin>>o;
    cin>>p;

}

void FHSS :: fhss_graph(){

    line(35,170,35,390);  //Vertical line
    line(35,390, 475, 390); //Horizontal line


    //Values of Frequencies in HORIZONTAL AXIS

    outtextxy(2,375, "100");
    outtextxy(2, 350, "200");
    outtextxy(2, 325, "300");
    outtextxy(2, 300, "400");
    outtextxy(2, 275, "500");
    outtextxy(2, 250, "600");
    outtextxy(2, 225, "700");
    outtextxy(2, 200, "800");

    //Values of Hop Periods in VERTICAL AXIS
    outtextxy(45, 405, "1");
    outtextxy(70, 405, "2");
    outtextxy(95, 405, "3");
    outtextxy(120, 405, "4");
    outtextxy(145, 405, "5");
    outtextxy(170, 405, "6");
    outtextxy(195, 405, "7");
    outtextxy(220, 405, "8");
    outtextxy(245, 405, "9");
    outtextxy(270, 405, "10");
    outtextxy(295, 405, "11");
    outtextxy(320, 405, "12");
    outtextxy(345, 405, "13");
    outtextxy(370, 405, "14");
    outtextxy(395, 405, "15");
    outtextxy(420, 405, "16");
    line(235, 185, 235, 390); //Middle line between two Cycles graph
    setcolor(GREEN);
    //To draw the horizontal lines in graph
    line(35,365,435,365);
    line(35,340,435,340);
    line(35,315,435,315);
    line(35,290,435,290);
    line(35,265,435,265);
    line(35,240,435,240);
    line(35,215,435,215);
    line(35,190,435,190);

    //To draw the vertical lines in graph;
    line(60, 185, 60, 390);
    line(85, 185, 85, 390);
    line(110, 185, 110, 390);
    line(135, 185, 135, 390);
    line(160, 185, 160, 390);
    line(185, 185, 185, 390);
    line(210, 185, 210, 390);

    //To draw Vertical lines in Cycles-2

    line(260, 185, 260, 390);
    line(285, 185, 285, 390);
    line(310, 185, 310, 390);
    line(335, 185, 335, 390);
    line(360, 185, 360, 390);
    line(385, 185, 385, 390);
    line(410, 185, 410, 390);
    line(435, 185, 435, 390);

    setcolor(WHITE);
    outtextxy(110,165, "CYCLE - 1");
    outtextxy(310, 165, "CYCLE - 2");
    outtextxy(210, 125, "FHSS CYCLES");
    outtextxy(0, 125, "CARRIER");
    outtextxy(0, 140, "FREQUENCIES");
    outtextxy(10, 155, "(KHz)");
    outtextxy(467, 405, "HOP");
    outtextxy(467, 420, "PERIODS");


}


void FHSS :: fhss_showdata(){
    setfillstyle(SOLID_FILL, LIGHTBLUE);

    //--i--

    if(i == 000){
        bar(35,365,60,390);
        setfillstyle(SOLID_FILL, MAGENTA);
        bar(235, 365, 260, 390);
    }
    else if(i == 001){
        bar(35,340,60,365);
        setfillstyle(SOLID_FILL, MAGENTA);
        bar(235, 340, 260, 365);
    }
    else if(i == 010){
        bar(35,315,60,340);
        setfillstyle(SOLID_FILL, MAGENTA);
        bar(235, 315, 260, 340);
    }
    else if(i == 011){
        bar(35,290,60,315);
        setfillstyle(SOLID_FILL, MAGENTA);
        bar(235, 290, 260, 315);
    }
    else if(i == 100){
        bar(35,265,60,290);
        setfillstyle(SOLID_FILL, MAGENTA);
        bar(235, 265, 260, 290);
    }
    else if(i == 101){
        bar(35,240,60,265);
        setfillstyle(SOLID_FILL, MAGENTA);
        bar(235, 240, 260, 265);
    }
    else if(i == 110){
        bar(35,215,60,240);
        setfillstyle(SOLID_FILL, MAGENTA);
        bar(235, 215, 260, 240);
    }
    else if(i == 111){
        bar(35,190,60,215);
        setfillstyle(SOLID_FILL, MAGENTA);
        bar(235, 190, 260, 215);
    }
    setfillstyle(SOLID_FILL, LIGHTBLUE);

    //----j---
    if(j == 000){
        bar(60,365,85,390);
        setfillstyle(SOLID_FILL, MAGENTA);
        bar(260, 365, 285, 390);
    }
    else if(j == 001){
        bar(60,340,85,365);
        setfillstyle(SOLID_FILL, MAGENTA);
        bar(260, 340, 285, 365);
    }
    else if(j == 010){
        bar(60,315,85,340);
        setfillstyle(SOLID_FILL, MAGENTA);
        bar(260, 315, 285, 340);
    }
    else if(j == 011){
        bar(60,290,85,315);
        setfillstyle(SOLID_FILL, MAGENTA);
        bar(260, 290, 285, 315);
    }
    else if(j == 100){
        bar(60,265,85,290);
        setfillstyle(SOLID_FILL, MAGENTA);
        bar(260, 265, 285, 290);
    }
    else if(j == 101){
        bar(60,240,85,265);
        setfillstyle(SOLID_FILL, MAGENTA);
        bar(260, 240, 285, 265);
    }
    else if(j == 110){
        bar(60,215,85,240);
        setfillstyle(SOLID_FILL, MAGENTA);
        bar(260, 215, 285, 240);
    }
    else if(j == 111){
        bar(60,190,85,215);
        setfillstyle(SOLID_FILL, MAGENTA);
        bar(260, 190, 285, 215);
    }

    //---k---
    setfillstyle(SOLID_FILL, LIGHTBLUE);

    if(k == 000){
        bar(85,365,110,390);
        setfillstyle(SOLID_FILL, MAGENTA);
        bar(285, 365, 310, 390);
    }
    else if(k == 001){
        bar(85,340,110,365);
        setfillstyle(SOLID_FILL, MAGENTA);
        bar(285, 340, 310, 365);
    }
    else if(k == 010){
        bar(85, 315, 110, 340);
        setfillstyle(SOLID_FILL, MAGENTA);
        bar(285, 315, 310, 340);
    }
    else if(k == 011){
        bar(85,290,110,315);
        setfillstyle(SOLID_FILL, MAGENTA);
        bar(285, 290, 310, 315);
    }
    else if(k == 100){
        bar(85,265,110,290);
        setfillstyle(SOLID_FILL, MAGENTA);
        bar(285, 265, 310, 290);
    }
    else if(k == 101){
        bar(85,240,110,265);
        setfillstyle(SOLID_FILL, MAGENTA);
        bar(285, 240, 310, 265);
    }
    else if(k == 110){
        bar(85,215,110,240);
        setfillstyle(SOLID_FILL, MAGENTA);
        bar(285, 215, 310, 240);
    }
    else if(k == 111){
        bar(85,190,110,215);
        setfillstyle(SOLID_FILL, MAGENTA);
        bar(285, 190, 310, 215);
    }

    //--l--
    setfillstyle(SOLID_FILL, LIGHTBLUE);

    if(l == 000){
        bar(110,365,135,390);
        setfillstyle(SOLID_FILL, MAGENTA);
        bar(310, 365, 335, 390);
    }
    else if(l == 001){
        bar(110,340,135,365);
        setfillstyle(SOLID_FILL, MAGENTA);
        bar(310, 340, 335, 365);
    }
    else if(l == 010){
        bar(110,315,135,340);
        setfillstyle(SOLID_FILL, MAGENTA);
        bar(310, 315, 335, 340);
    }
    else if(l == 011){
        bar(110, 290, 135, 315);
        setfillstyle(SOLID_FILL, MAGENTA);
        bar(310, 290, 335, 315);
    }
    else if(l == 100){
        bar(110,265,135,290);
        setfillstyle(SOLID_FILL, MAGENTA);
        bar(310, 265, 335, 290);
    }
    else if(l == 101){
        bar(110,240,135,265);
        setfillstyle(SOLID_FILL, MAGENTA);
        bar(310, 240, 335, 265);
    }
    else if(l == 110){
        bar(110,215,135,240);
        setfillstyle(SOLID_FILL, MAGENTA);
        bar(310, 215, 335, 240);
    }
    else if(l == 111){
        bar(110,190,135,215);
        setfillstyle(SOLID_FILL, MAGENTA);
        bar(310, 190, 335, 215);
    }

    //--m--
    setfillstyle(SOLID_FILL, LIGHTBLUE);

    if(m == 000){
        bar(135,365,160,390);
        setfillstyle(SOLID_FILL, MAGENTA);
        bar(335, 365, 360, 390);
    }
    else if(m == 001){
        bar(135,340,160,365);
        setfillstyle(SOLID_FILL, MAGENTA);
        bar(335, 340, 360, 365);
    }
    else if(m == 010){
        bar(135,315,160,340);
        setfillstyle(SOLID_FILL, MAGENTA);
        bar(335, 315, 360, 340);
    }
    else if(m == 011){
        bar(135,290,160,315);
        setfillstyle(SOLID_FILL, MAGENTA);
        bar(335, 290, 360, 315);
    }
    else if(m == 100){
        bar(135,265,160,290);
        setfillstyle(SOLID_FILL, MAGENTA);
        bar(335, 265, 360, 290);
    }
    else if(m == 101){
        bar(135,240,160,265);
        setfillstyle(SOLID_FILL, MAGENTA);
        bar(335, 240, 360, 265);
    }
    else if(m == 110){
        bar(135,215,160,240);
        setfillstyle(SOLID_FILL, MAGENTA);
        bar(335, 215, 360, 240);
    }
    else if(m == 111){
        bar(135,190,160,215);
        setfillstyle(SOLID_FILL, MAGENTA);
        bar(335, 190, 360, 215);
    }

    //--n--
    setfillstyle(SOLID_FILL, LIGHTBLUE);

    if(n == 000){
        bar(160,365,185,390);
        setfillstyle(SOLID_FILL, MAGENTA);
        bar(360, 365, 385, 390);
    }
    else if(n == 001){
        bar(160,340,185,365);
        setfillstyle(SOLID_FILL, MAGENTA);
        bar(360, 340, 385, 365);
    }
    else if(n == 010){
        bar(160,315,185,340);
        setfillstyle(SOLID_FILL, MAGENTA);
        bar(360, 315, 385, 340);
    }
    else if(n == 011){
        bar(160,290,185,315);
        setfillstyle(SOLID_FILL, MAGENTA);
        bar(360, 290, 385, 315);
    }
    else if(n == 100){
        bar(160,265,185,290);
        setfillstyle(SOLID_FILL, MAGENTA);
        bar(360, 265, 385, 290);
    }
    else if(n == 101){
        bar(160,240,185,265);
        setfillstyle(SOLID_FILL, MAGENTA);
        bar(360, 240, 385, 265);
    }
    else if(n == 110){
        bar(160,215,185,240);
        setfillstyle(SOLID_FILL, MAGENTA);
        bar(360, 215, 385, 240);
    }
    else if(n == 111){
        bar(160,190,185,215);
        setfillstyle(SOLID_FILL, MAGENTA);
        bar(360, 190, 385, 215);
    }

    //--o--
    setfillstyle(SOLID_FILL, LIGHTBLUE);


    if(o == 000){
        bar(185,365,210,390);
        setfillstyle(SOLID_FILL, MAGENTA);
        bar(385, 365, 410, 390);
    }
    else if(o == 001){011;
        bar(185,340,210,365);
        setfillstyle(SOLID_FILL, MAGENTA);
        bar(385, 340, 410, 365);
    }
    else if(o == 010){
        bar(185,315,210,340);
        setfillstyle(SOLID_FILL, MAGENTA);
        bar(385, 315, 410, 340);
    }
    else if(o == 011){
        bar(185,290,210,315);
        setfillstyle(SOLID_FILL, MAGENTA);
        bar(385, 290, 410, 315);
    }
    else if(o == 100){
        bar(185,265,210,290);
        setfillstyle(SOLID_FILL, MAGENTA);
        bar(385, 265, 410, 290);
    }
    else if(o == 101){
        bar(185,240,210,265);
        setfillstyle(SOLID_FILL, MAGENTA);
        bar(385, 240, 410, 265);
    }
    else if(o == 110){
        bar(185,215,210,240);
        setfillstyle(SOLID_FILL, MAGENTA);
        bar(385, 215, 410, 240);
    }
    else if(o == 111){
        bar(185,190,210,215);
        setfillstyle(SOLID_FILL, MAGENTA);
        bar(385, 190, 410, 215);
    }


    //--p--
    setfillstyle(SOLID_FILL, LIGHTBLUE);


    if(p == 000){
        bar(210,365,235,390);
        setfillstyle(SOLID_FILL, MAGENTA);
        bar(410, 365, 435, 390);
    }
    else if(p == 001){
        bar(210,340,235,365);
        setfillstyle(SOLID_FILL, MAGENTA);
        bar(410, 340, 435, 365);
    }
    else if(p == 010){
        bar(210,315,235,340);
        setfillstyle(SOLID_FILL, MAGENTA);
        bar(410, 315, 435, 340);
    }
    else if(p == 011){
        bar(210,290,235,315);
        setfillstyle(SOLID_FILL, MAGENTA);
        bar(410, 290, 435, 315);
    }
    else if(p == 100){
        bar(210,265,235,290);
        setfillstyle(SOLID_FILL, MAGENTA);
        bar(410, 265, 435, 290);
    }
    else if(p == 101){
        bar(210,240,235,265);
        setfillstyle(SOLID_FILL, MAGENTA);
        bar(410, 240, 435, 265);
    }
    else if(p == 110){
        bar(210,215,235,240);
        setfillstyle(SOLID_FILL, MAGENTA);
        bar(410, 215, 435, 240);
    }
    else if(p == 111){
        bar(210,190,235,215);
        setfillstyle(SOLID_FILL, MAGENTA);
        bar(410, 190, 435, 215);
    }

}


int main(){
    initwindow(1000,600);
    cout<<"--------------------Frequency Hopping Spread Spectrum--------------------"<<endl;


    FHSS f;
    f.fhss_getdata();

    f.fhss_graph();
    f.fhss_showdata();
    getch();
    closegraph();
    return 0;
}

